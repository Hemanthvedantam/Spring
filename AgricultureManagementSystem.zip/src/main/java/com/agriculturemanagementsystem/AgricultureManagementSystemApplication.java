
package com.agriculturemanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgricultureManagementSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgricultureManagementSystemApplication.class, args);
    }
}
